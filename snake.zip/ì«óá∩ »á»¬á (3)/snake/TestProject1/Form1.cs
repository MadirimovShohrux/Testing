﻿namespace Snake.Tests
{
    internal class Form1
    {
        public Form1()
        {
        }

        internal object? GetScore()
        {
            throw new NotImplementedException();
        }

        internal void InvokeCheckBorders()
        {
            throw new NotImplementedException();
        }
    }
}