﻿using System;

namespace ClassLibrary1
{
    public class Class1
    {
        public int Add(int a, int b)
        {
            return a + b;
        }

        public int Subtract(int a, int b)
        {
            return a - b;
        }

        public double Sin(double angleInDegrees)
        {
            double angleInRadians = Math.PI * angleInDegrees / 180.0;
            return Math.Sin(angleInRadians);
        }

        public double Cos(double angleInDegrees)
        {
            double angleInRadians = Math.PI * angleInDegrees / 180.0;
            return Math.Cos(angleInRadians);
        }

        public int Modulus(int a, int b)
        {
            if (b == 0)
            {
                throw new ArgumentException("Cannot divide by zero", nameof(b));
            }

            return a % b;
        }
    }
}
