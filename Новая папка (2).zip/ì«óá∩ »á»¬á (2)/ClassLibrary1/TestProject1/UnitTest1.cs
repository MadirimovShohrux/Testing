using NUnit.Framework;
using ClassLibrary1;
using System;

namespace Tests
{
    [TestFixture]
    public class Class1Tests
    {
        [Test]
        public void Add_ShouldReturnCorrectSum()
        {
            // Arrange
            Class1 calculator = new Class1();

            // Act
            int result = calculator.Add(3, 5);

            // Assert
            Assert.AreEqual(8, result);
        }

        [Test]
        public void Subtract_ShouldReturnCorrectDifference()
        {
            // Arrange
            Class1 calculator = new Class1();

            // Act
            int result = calculator.Subtract(10, 4);

            // Assert
            Assert.AreEqual(6, result);
        }

        [Test]
        public void Sin_ShouldReturnCorrectValue()
        {
            // Arrange
            Class1 calculator = new Class1();

            // Act
            double result = calculator.Sin(30);

            // Assert
            Assert.AreEqual(0.5, result, 0.0001);
        }

        [Test]
        public void Cos_ShouldReturnCorrectValue()
        {
            // Arrange
            Class1 calculator = new Class1();

            // Act
            double result = calculator.Cos(60);

            // Assert
            Assert.AreEqual(0.5, result, 0.0001);
        }

        [Test]
        public void Modulus_ShouldReturnCorrectResult()
        {
            // Arrange
            Class1 calculator = new Class1();

            // Act
            int result = calculator.Modulus(10, 3);

            // Assert
            Assert.AreEqual(1, result);
        }

        [Test]
        public void Modulus_ShouldThrowExceptionWhenDividingByZero()
        {
            // Arrange
            Class1 calculator = new Class1();

            // Act & Assert
            Assert.Throws<ArgumentException>(() => calculator.Modulus(10, 0));
        }
    }
}
